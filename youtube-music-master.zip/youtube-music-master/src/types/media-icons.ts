export const mediaIcons = {
  play: '\u{1405}', // ᐅ
  pause: '\u{2016}', // ‖
  next: '\u{1433}', // ᐳ
  previous: '\u{1438}', // ᐸ
} as const;
