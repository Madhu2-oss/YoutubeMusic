export interface SearchBoxElement extends HTMLElement {
  getSearchboxStats(): unknown;
}
