export { register as registerControl } from './control';
export { register as registerAuth } from './auth';
