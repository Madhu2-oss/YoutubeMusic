export declare const injectCpuTamerByDomMutation: (
  __CONTEXT__: unknown,
) => void;
