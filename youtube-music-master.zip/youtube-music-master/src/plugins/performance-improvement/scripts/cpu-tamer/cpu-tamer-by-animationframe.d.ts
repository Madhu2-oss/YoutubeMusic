export declare const injectCpuTamerByAnimationFrame: (
  __CONTEXT__: unknown,
) => void;
