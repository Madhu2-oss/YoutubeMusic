declare module 'simple-youtube-age-restriction-bypass' {
  export const inject: () => void;
}
