export const blockers = {
  WithBlocklists: 'With blocklists',
  InPlayer: 'In player',
  AdSpeedup: 'Ad speedup',
} as const;
