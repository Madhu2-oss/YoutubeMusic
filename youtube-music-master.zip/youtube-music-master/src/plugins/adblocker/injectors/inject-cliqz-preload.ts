export default async () => {
  await import('@ghostery/adblocker-electron-preload');
};
