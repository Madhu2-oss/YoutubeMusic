export const getSongMenu = () =>
  document.querySelector('ytmusic-menu-popup-renderer tp-yt-paper-listbox');

export default { getSongMenu };
