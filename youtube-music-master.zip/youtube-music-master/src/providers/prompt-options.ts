import youtubeMusicTrayIcon from '@assets/youtube-music-tray.png?asset&asarUnpack';

const promptOptions = {
  customStylesheet: 'dark',
  icon: youtubeMusicTrayIcon,
};

export default () => promptOptions;
